import { Spin } from 'antd'

export default function Loading() {
    return <Spin />
}