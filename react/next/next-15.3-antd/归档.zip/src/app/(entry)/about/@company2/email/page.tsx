export default function Email() {
    return <span>company2@my.com</span>
}