export default function Tel() {
    return <span>010-12345678</span>
}