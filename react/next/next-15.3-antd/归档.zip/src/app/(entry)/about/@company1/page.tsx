export default function Location() {
    return <span>北京市</span>
}