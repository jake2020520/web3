export default function Email() {
    return <span>company1@my.com</span>
}