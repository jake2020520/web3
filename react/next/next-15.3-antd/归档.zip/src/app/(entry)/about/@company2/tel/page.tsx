export default function Tel() {
    return <span>022-12345678</span>
}