export default function Location() {
    return <span>天津市</span>
}