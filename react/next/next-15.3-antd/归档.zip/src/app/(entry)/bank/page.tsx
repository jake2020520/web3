import styles from "./bank.module.scss";
export default function Home() {
  return (
    <div className={styles["P-bank"]}>
      <div>bank</div>
    </div>
  );
}
