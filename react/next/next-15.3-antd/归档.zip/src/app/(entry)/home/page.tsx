import ServerList from './serverList'
export default function Home() {
    return (
        <div className="P-home">
            <div>houme</div>
            <ServerList />
        </div>
    )
}